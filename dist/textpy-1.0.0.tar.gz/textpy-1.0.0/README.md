# textpy
text-fabric "lean": compute in notebooks, but no text-fabric browser
