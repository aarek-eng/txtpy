

class Computeds(object):
    pass


class Computed(object):

    def __init__(self, api, data):
        self.api = api
        self.data = data
